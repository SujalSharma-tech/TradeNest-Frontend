import "./singleproductpage.scss";
import { useNavigate, useParams } from "react-router-dom";
import iphone from "./iphone.png";
import { Fragment, useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { useAppStore } from "../../store";
const SingleProductPage = () => {
  const navigate = useNavigate();
  const [product, setProduct] = useState({});
  const { id } = useParams();
  console.log(id);

  const { products } = useAppStore();
  console.log(products);

  useEffect(() => {
    const filteredProduct = products.filter((product) => product._id === id);
    console.log(filteredProduct);
    setProduct(filteredProduct);
  }, [products, id]);
  console.log(product);
  const handleBackClick = () => {
    if (window.history.state && window.history.state.idx > 0) {
      navigate(-1);
    } else {
      navigate("/");
    }
  };
  const productData = {
    PR: "#1",
    Category: "Mobile Phone",
    Brand: "Apple",
    Condition: "Gently Used",
    Color: "Starlight",
    Warranty: "No",
    DentsScratches: "Minor",
    Location: "Phagwara",
    PublishedDate: "12-Oct-2024",
    AdditionalInfo:
      "Pure breed Shih Tzu.\nGood body structure.\nWith MKA cert and Microchip.\nFather from champion lineage.",
  };

  const keyDisplayNameMap = {
    AdditionalInfo: "Additional Info",
    DentsScratches: "Dents/Scratches",
    PublishedDate: "Published Date",
  };
  return product.length > 0 ? (
    <div className="singleproductpage">
      {console.log(product)}
      <button onClick={handleBackClick} className="back-btn">
        <ArrowLeft size={18} /> Back
      </button>

      <div className="main-container">
        <div className="left">
          <div className="main">
            <div className="main-cover-photo">
              <img src={iphone} alt="" />
            </div>
          </div>
          <div className="slider-main">
            <div className="photo-slider">
              <div className="img-body-small">
                <img src={iphone} alt="" />
              </div>
              <div className="img-body-small">
                <img src={iphone} alt="" />
              </div>
              <div className="img-body-small">
                <img src={iphone} alt="" />
              </div>
              <div className="img-body-small">
                <img src={iphone} alt="" />
              </div>
              <div className="img-body-small">
                <img src={iphone} alt="" />
              </div>
            </div>
          </div>
        </div>
        <div className="right">
          <div className="nav-history">
            <p>
              Home {">"} Buy {">"} {product[0].category} {">"} {product.title}
            </p>
          </div>

          <div className="product-id">PR # {product[0]._id}</div>
          <div className="product-title">{product[0].title}</div>
          <div className="price">{product[0].details?.price}</div>

          <div className="contact-btns">
            <button className="contact-btn">Contact No.</button>
            <button className="contact-btn">Message</button>
          </div>
          {/* <div className="main-details">
            <div className="product-details">
              <div className="category-detail">
                <div className="detail-box-title">PR</div>
                <div className="detail-box-title">Category</div>
                <div className="detail-box-title">Brand</div>
                <div className="detail-box-title">Color</div>
                <div className="detail-box-title">Condition</div>
                <div className="detail-box-title">Warranty</div>
                <div className="detail-box-title">Dent/Scratches</div>
                <div className="detail-box-title">Location</div>
                <div className="detail-box-title">Published Date</div>
                <div className="detail-box-title">Additional Information</div>
              </div>
              <div className="category-detail-data">
                <div className="detail-box-body">: #1</div>
                <div className="detail-box-body">: Mobile Phone</div>
                <div className="detail-box-body">: Apple</div>
                <div className="detail-box-body">: Starlight</div>
                <div className="detail-box-body">: Gently Used</div>
                <div className="detail-box-body">: No</div>
                <div className="detail-box-body">: No</div>
                <div className="detail-box-body">: Phagwara</div>
                <div className="detail-box-body">: 12-Oct-2024</div>
                <div className="detail-box-body">
                  : something here about product
                </div>
              </div>
            </div>
          </div> */}
          <div className="product-details">
            <table className="details-table">
              <tbody>
                {product.length > 0
                  ? Object.entries(product[0]?.details).map(([key, value]) => (
                      <tr key={key}>
                        <td className="label-cell">
                          {keyDisplayNameMap[key] || key}
                        </td>
                        <td className="value-cell">
                          {": "}
                          {value.includes("\n")
                            ? value.split("\n").map((line, index) => (
                                <Fragment key={index}>
                                  {line}
                                  <br />
                                </Fragment>
                              ))
                            : value}
                        </td>
                      </tr>
                    ))
                  : ""}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  ) : (
    "Loading..."
  );
};

export default SingleProductPage;
